namespace AudioPool.Models.DTOs
{
    public class GenreDto : HyperMediaModel
    {
        // GenreDto
        // ○ Id (int)
        public int Id { get; set; }
        // ○ Name (string)
        public string Name { get; set; }

    }
}

