
using Datafication.Repositories.Data;
using Datafication.Repositories.Implementations;
using Datafication.Repositories.Interfaces;
using Datafication.Services.Implementations;
using Datafication.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddTransient<IManufacturerService, ManufacturerService>();
builder.Services.AddTransient<IImageService, ImageService>();
builder.Services.AddTransient<IIceCreamService, IceCreamService>();
builder.Services.AddTransient<ICategoryService, CategoryService>();

builder.Services.AddTransient<IManufacturerRepository, ManufacturerRepository>();
builder.Services.AddTransient<IImageRepository, ImageRepository>();
builder.Services.AddTransient<IIceCreamRepository, IceCreamRepository>();
builder.Services.AddTransient<ICategoryRepository, CategoryRepository>();


// Adding DbContext service
builder.Services.AddDbContext<IceCreamDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("IceCreamDb"),
        b => b.MigrationsAssembly("Datafication.Repositories")));


builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
