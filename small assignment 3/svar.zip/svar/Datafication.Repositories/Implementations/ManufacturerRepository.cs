using System.Collections.Generic;
using System.Linq;
using Datafication.Models.Dtos;
using Datafication.Repositories.Data;
using Datafication.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Datafication.Repositories.Implementations
{
    public class ManufacturerRepository : IManufacturerRepository
    {
        private readonly IceCreamDbContext _context;

        public ManufacturerRepository(IceCreamDbContext context)
        {
            _context = context;
        }

        public ManufacturerDetailsDto GetManufacturerById(int id)
        {
            var manufacturer = _context.Manufacturers
                .FirstOrDefault(m => m.Id == id);
    
            if (manufacturer == null)
            {
                throw new ManufacturerNotFoundException(id);
            }

            var iceCreams = _context.IceCreams
                .Where(ice => ice.ManufacturerId == manufacturer.Id)
                .Include(ice => ice.Categories) // Include Categories in the query
                .Select(ice => new IceCreamDto
                {
                    Id = ice.Id,
                    Name = ice.Name,
                    Description = ice.Description
                }).ToList();
    
            // Calculate unique categories for the ice creams of this manufacturer
            var categoryIds = new HashSet<int>();
            foreach (var iceCream in _context.IceCreams
                         .Where(ice => ice.ManufacturerId == manufacturer.Id)
                         .Include(ice => ice.Categories))
            {
                foreach (var category in iceCream.Categories)
                {
                    categoryIds.Add(category.Id);
                    if (category.ParentCategoryId != null) {
                        categoryIds.Add(category.ParentCategoryId.Value);
                    }
                }
            }
            var categoryOccurrence = categoryIds.Count;
    
            var dto = new ManufacturerDetailsDto
            {
                Id = manufacturer.Id,
                Name = manufacturer.Name,
                Bio = manufacturer.Bio,
                ExternalUrl = manufacturer.ExternalUrl,
                IceCreams = iceCreams,
                CategoryOccurrance = categoryOccurrence
            };

            return dto;
        }

    }
}