using System.Collections.Generic;
using System.Linq;
using Datafication.Models.Dtos;
using Datafication.Models.InputModels;
using Datafication.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;
using Datafication.Models.Entities;
using System;
using Datafication.Repositories.Data;

namespace Datafication.Repositories.Implementations
{
    public class CategoryNotFoundException : Exception
    {
        public CategoryNotFoundException(int categoryId) 
            : base($"No category found with the ID: {categoryId}")
        { }
    }

    public class ParentCategoryNotFoundException : Exception
    {
        public ParentCategoryNotFoundException(int categoryId)
            : base($"No parent category found with the ID: {categoryId}")
        { }
    }
    public class CategoryRepository : ICategoryRepository
    {
        private readonly IceCreamDbContext _context;

        public CategoryRepository(IceCreamDbContext context)
        {
            _context = context;
        }

        public int CreateNewCategory(CategoryInputModel category)
        {   
            var parentCategory = _context.Categories.Find(category.ParentCategoryId);
            if (parentCategory == null)
            {
                throw new ParentCategoryNotFoundException(category.ParentCategoryId.Value);
            }
            
            var newCategory = new Category
            {
                Name = category.Name,
                ParentCategoryId = category.ParentCategoryId,
            };

            _context.Categories.Add(newCategory);
            _context.SaveChanges();

            return newCategory.Id;
        }

        public void DeleteCategory(int id)
        {
            var category = _context.Categories.Find(id);
            if (category == null)
            {
                throw new CategoryNotFoundException(id);
            }
            _context.Categories.Remove(category);
            _context.SaveChanges();
        }

        

        public IEnumerable<IceCreamDto> GetIceCreamsByCategoryId(int id)
        {
            var category = _context.Categories.Find(id);
            if (category == null)
            {
                throw new CategoryNotFoundException(id);
            }
            // Fetch ice creams linked to the given category.
            var iceCreamsForCategory = _context.Categories
                .Where(c => c.Id == id)
                .SelectMany(c => c.IceCreams)
                .Select(ic => new IceCreamDto
                {
                    Id = ic.Id,
                    Name = ic.Name,
                    Description = ic.Description
                })
                .ToList();

            // Check if the category has a parent category.
            var parentCategoryId = _context.Categories
                .Where(c => c.Id == id)
                .Select(c => c.ParentCategoryId)
                .FirstOrDefault();

            if (parentCategoryId.HasValue)
            {
                // Fetch ice creams linked to the parent category.
                var iceCreamsForParentCategory = _context.Categories
                    .Where(c => c.Id == parentCategoryId.Value)
                    .SelectMany(c => c.IceCreams)
                    .Select(ic => new IceCreamDto
                    {
                        Id = ic.Id,
                        Name = ic.Name,
                        Description = ic.Description
                    })
                    .ToList();

                // Combine the results.
                iceCreamsForCategory.AddRange(iceCreamsForParentCategory);
            }

            return iceCreamsForCategory.Distinct().ToList();
        }
    }
}
