using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Datafication.Models.Dtos;
using Datafication.Models.InputModels;
using Datafication.Models.Entities;
using Datafication.Repositories.Interfaces;
using System.Linq;
using Datafication.Repositories.Data;

namespace Datafication.Repositories.Implementations
{
    public class IceCreamNotFoundException : Exception
    {
        public IceCreamNotFoundException(int iceCreamId) 
            : base($"No ice cream found with the ID: {iceCreamId}")
        { }
    }
    
    public class ManufacturerNotFoundException : Exception
    {
        public ManufacturerNotFoundException(int manufacturerId)
            : base($"No manufacturer found with the ID: {manufacturerId}")
        { }
    }
    
    
    public class IceCreamRepository : IIceCreamRepository
    {
        private readonly IceCreamDbContext _context;

        public IceCreamRepository(IceCreamDbContext context)
        {
            _context = context;
        }

        public void AddIceCreamToCategory(int iceCreamId, int categoryId)
        {
            var iceCream = _context.IceCreams
                .Include(ic => ic.Categories)  // Explicitly load Categories
                .SingleOrDefault(ic => ic.Id == iceCreamId);
                            
            var category = _context.Categories
                .SingleOrDefault(c => c.Id == categoryId);
            
            if (iceCream == null)
            {
                throw new IceCreamNotFoundException(iceCreamId);
            }

            if (category == null)
            {
                throw new CategoryNotFoundException(categoryId);
            }

            if (iceCream.Categories == null)
            {
                iceCream.Categories = new List<Category>();
            }

            // Add the category to the ice cream's Categories list.
            iceCream.Categories.Add(category);

            _context.SaveChanges();
        }



        public int CreateNewIceCream(IceCreamInputModel iceCream)
        {
            var manufacturer = _context.Manufacturers.Find(iceCream.ManufacturerId);
            if (manufacturer == null)
            {
                throw new ManufacturerNotFoundException(iceCream.ManufacturerId);
            }
            var newIceCream = new IceCream
            {
                Name = iceCream.Name,
                Description = iceCream.Description,
                ManufacturerId = iceCream.ManufacturerId
            };

            _context.IceCreams.Add(newIceCream);
            _context.SaveChanges();

            return newIceCream.Id;
        }

        public void DeleteIceCream(int id)
        {
            var iceCreamToDelete = _context.IceCreams.Find(id);
            if (iceCreamToDelete != null)
            {
                _context.IceCreams.Remove(iceCreamToDelete);
                _context.SaveChanges();
            }
            else
            {
                throw new IceCreamNotFoundException(id);
            }
        }

        public IEnumerable<IceCreamDto> GetAllIceCreams()
        {
            return _context.IceCreams
                .Include(ic => ic.Manufacturer)
                .Select(iceCream => new IceCreamDto
                {
                    Id = iceCream.Id,
                    Name = iceCream.Name,
                    Description = iceCream.Description
                })
                .ToList();
        }

       public IceCreamDetailsDto GetIceCreamById(int id)
        {
        // Explicitly load related entities
        var iceCream = _context.IceCreams
            .Include(ic => ic.Manufacturer)
            .Include(ic => ic.Categories)  // Explicitly load Categories
            .FirstOrDefault(ic => ic.Id == id);

        if (iceCream == null)
        {
            throw new IceCreamNotFoundException(id);
        }

        var images = _context.Images
            .Where(img => img.IceCreamId == id)
            .Select(img => new ImageDto
            {
                Id = img.Id,
                Url = img.Url
            })
            .ToList();

        // Use the already loaded categories from iceCream
        var categories = iceCream.Categories.Select(c => new CategoryDto
        {
            Id = c.Id,
            Name = c.Name,
            ParentCategoryId = c.ParentCategoryId
        }).ToList();

        var dto = new IceCreamDetailsDto
        {
            Id = iceCream.Id,
            Name = iceCream.Name,
            Description = iceCream.Description,
            Manufacturer = new ManufacturerDto
            {
                Id = iceCream.ManufacturerId,
                Name = iceCream.Manufacturer.Name,
                ExternalUrl = iceCream.Manufacturer.ExternalUrl
            },
            Images = images,
            Categories = categories  // Use the populated categories list
        };

        return dto;
        }


        public void UpdateIceCream(int id, IceCreamInputModel iceCream)
        {
            var existingIceCream = _context.IceCreams.Find(id);
            var manufacturer = _context.Manufacturers.Find(iceCream.ManufacturerId);
            if (manufacturer == null)
            {
                throw new ManufacturerNotFoundException(iceCream.ManufacturerId);
            }
            if (existingIceCream != null)
            {
                existingIceCream.Name = iceCream.Name;
                existingIceCream.Description = iceCream.Description;
                existingIceCream.ManufacturerId = iceCream.ManufacturerId;

                _context.SaveChanges();
            }
            else
            {
                throw new IceCreamNotFoundException(id);
            }
        }
    }
}
