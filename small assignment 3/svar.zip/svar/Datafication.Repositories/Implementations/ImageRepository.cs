using System;
using System.Collections.Generic;
using Datafication.Models.Dtos;
using Datafication.Models.InputModels;
using Datafication.Models.Entities;
using Datafication.Repositories.Interfaces;
using System.Linq;
using Datafication.Repositories.Data;
using Microsoft.EntityFrameworkCore;

namespace Datafication.Repositories.Implementations
{
    public class ImageNotFoundException : Exception
    {
        public ImageNotFoundException(int imageId)
            : base($"No image found with the ID: {imageId}")
        { }
    }
    public class ImageRepository : IImageRepository
    {
        private readonly IceCreamDbContext _context;

        public ImageRepository(IceCreamDbContext context)
        {
            _context = context;
        }

        public int CreateNewImage(ImageInputModel image)
        {
            var iceCream = _context.IceCreams.Find(image.IceCreamId);
            if (iceCream == null)
            {
                throw new IceCreamNotFoundException(image.IceCreamId);
            }
            var newImage = new Image
            {
                Url = image.Url,
                IceCreamId = image.IceCreamId
            };

            _context.Images.Add(newImage);
            _context.SaveChanges();

            return newImage.Id;
        }

        public IEnumerable<ImageDto> GetAllImagesByIceCreamId(int iceCreamId)
        {
            var iceCream = _context.IceCreams.Find(iceCreamId);
            if (iceCream == null)
            {
                throw new IceCreamNotFoundException(iceCreamId);
            }
            var images =_context.Images
                .Where(img => img.IceCreamId == iceCreamId)
                .Select(img => new ImageDto
                {
                    Id = img.Id,
                    Url = img.Url
                })
                .ToList();
            return images;
        }

        public ImageDetailsDto GetImageById(int id)
        {
            var image = _context.Images
                .Include(img => img.IceCream)
                .FirstOrDefault(img => img.Id == id);

            if (image == null)
            {
                throw new ImageNotFoundException(id);
            }

            var IceCream = _context.IceCreams
                .Include(ic => ic.Manufacturer)
                .FirstOrDefault(ic => ic.Id == image.IceCreamId);
            
            var dto = new ImageDetailsDto
            {
                Id = image.Id,
                Url = image.Url,
                IceCream = new IceCreamDto
                {
                   Id = IceCream.Id,
                   Name = IceCream.Name,
                   Description = IceCream.Description
                }
            };
            return dto;
            
        }
    }
}