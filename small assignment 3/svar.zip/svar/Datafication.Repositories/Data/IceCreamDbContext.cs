using Microsoft.EntityFrameworkCore;
using Datafication.Models.Entities;
using System;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Datafication.Repositories.Data
{
    public class IceCreamDbContext : DbContext
    {
        public IceCreamDbContext(DbContextOptions<IceCreamDbContext> options) : base(options) { }
        public DbSet<Category> Categories { get; set; }
        public DbSet<IceCream> IceCreams { get; set; }
        public DbSet<Image> Images { get; set; }
        public DbSet<Manufacturer> Manufacturers { get; set; }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<IceCream>()
                .HasMany(ic => ic.Categories)
                .WithMany(c => c.IceCreams)
                .UsingEntity(j => j.ToTable("CategoryIceCream"));
            
            modelBuilder.Entity<Category>()
                .HasOne(c => c.ParentCategory)
                .WithMany()
                .HasForeignKey(c => c.ParentCategoryId)
                .OnDelete(DeleteBehavior.SetNull);

            // Common method to configure CreatedDate and ModifiedDate
            Action<EntityTypeBuilder> configureTimestamps = e =>
            {
                e.Property<DateTime>("CreatedDate")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .ValueGeneratedOnAdd();
                
                e.Property<DateTime>("ModifiedDate")
                    .HasDefaultValueSql("CURRENT_TIMESTAMP")
                    .ValueGeneratedOnAddOrUpdate();
            };

            modelBuilder.Entity<Manufacturer>(configureTimestamps);
            modelBuilder.Entity<IceCream>(configureTimestamps);
            modelBuilder.Entity<Category>(configureTimestamps);
            modelBuilder.Entity<Image>(configureTimestamps);
        }
        
    }
    
}