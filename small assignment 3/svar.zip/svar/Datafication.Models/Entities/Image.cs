namespace Datafication.Models.Entities
{
    public class Image
    {
        public int Id { get; set; }
        public int IceCreamId { get; set; }
        public string Url { get; set; }

        // Navigation properties
        public IceCream IceCream { get; set; }
    }
}