using System.Collections.Generic;

namespace Datafication.Models.Entities
{
    public class Category
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int? ParentCategoryId { get; set; }  // Nullable because a category might not have a parent

        // Navigation properties
        public Category ParentCategory { get; set; }
        public ICollection<IceCream> IceCreams { get; set; } = new List<IceCream>();
        
    }
}