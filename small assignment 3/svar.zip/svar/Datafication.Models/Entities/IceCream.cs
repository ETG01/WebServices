using System.Collections.Generic;

namespace Datafication.Models.Entities
{
    public class IceCream
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public int ManufacturerId { get; set; }

        // Navigation properties
        public Manufacturer Manufacturer { get; set; }
        public ICollection<Image> Images { get; set; }
        public ICollection<Category> Categories { get; set; }  = new List<Category>();
        
    }
}