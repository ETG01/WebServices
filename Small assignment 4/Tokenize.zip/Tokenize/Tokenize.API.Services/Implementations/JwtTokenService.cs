using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Tokenize.API.Models.DTOs;
using Tokenize.API.Services.Interfaces;

namespace Tokenize.API.Services.Implementations
{
    public class JwtTokenService : IJwtTokenService
    {
        private readonly IConfiguration _configuration;

        public JwtTokenService(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public string GenerateJWT(UserDto user)
        {
            var secret = _configuration.GetSection("JwtSettings:Secret").Value;
            var issuer = _configuration.GetSection("JwtSettings:Issuer").Value;
            var audience = _configuration.GetSection("JwtSettings:Audience").Value;

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
                new Claim("fullName", user.FullName),
                new Claim("email", user.EmailAddress),
                new Claim("NationalId", "0604012250")
            };

            var token = new JwtSecurityToken(
                issuer: issuer,
                audience: audience,
                claims: claims,
                expires: DateTime.Now.AddMinutes(1),  // Token will expire after 20 minutes
                signingCredentials: creds);
            

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
        
    }
}