using System.Security.Claims;
using Tokenize.API.Models.DTOs;
using Tokenize.API.Models.InputModels;
using Tokenize.API.Repositories.Interfaces;
using Tokenize.API.Services.Interfaces;
using Tokenize.API.Services.Utilities;
using Microsoft.Extensions.Configuration;

namespace Tokenize.API.Services.Implementations
{
    public class AccountService : IAccountService
    {
        private readonly IAccountRepository _accountRepository;
        private readonly IJwtTokenService _jwtTokenService;
        private readonly string _salt;

        public AccountService(IAccountRepository accountRepository, IJwtTokenService jwtTokenService, IConfiguration configuration)
        {
            _accountRepository = accountRepository;
            _jwtTokenService = jwtTokenService;
            _salt = configuration.GetSection("JwtSettings:Salt").Value ?? "";
        }

        public void Register(RegisterInputModel inputModel)
        {
            var hashedPassword = Hasher.HashPassword(inputModel.Password, _salt);
            _accountRepository.Register(inputModel, hashedPassword);
        }

        public string Login(LoginInputModel inputModel)
        {
            var hashedPassword = Hasher.HashPassword(inputModel.Password, _salt);
            var user = _accountRepository.GetUser(inputModel.EmailAddress, hashedPassword);
            if (user != null)
            {
                return _jwtTokenService.GenerateJWT(user);
            }
            return null;
        }
    }
}