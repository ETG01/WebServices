using Tokenize.API.Models.DTOs;
using Tokenize.API.Models.Entities;
using Tokenize.API.Repositories.Interfaces;
using Tokenize.API.Services.Interfaces;
using Microsoft.Extensions.Configuration;

namespace Tokenize.API.Services.Implementations
{
    public class BookService : IBookService
    {
        private readonly IBookRepository _bookRepository;
        private readonly IConfiguration _configuration;

        public BookService(IBookRepository bookRepository, IConfiguration configuration)
        {
            _bookRepository = bookRepository;
            _configuration = configuration;
        }

        public BookDto[] GetAllBooks()
        {
            return _bookRepository.GetAllBooks();
        }

        public BookDetailsDto? GetBookById(int id)
        {
            return _bookRepository.GetBookById(id);
        }

        public int CreateBook(Book book)
        {
            return _bookRepository.CreateBook(book);
        }

        public void UpdateBookById(int id, Book updatedBook)
        {
            _bookRepository.UpdateBookById(id, updatedBook);
        }
    }
}