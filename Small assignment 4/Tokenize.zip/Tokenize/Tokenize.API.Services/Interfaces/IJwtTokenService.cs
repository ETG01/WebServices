using Tokenize.API.Models.DTOs;

namespace Tokenize.API.Services.Interfaces
{
    public interface IJwtTokenService
    {
        string GenerateJWT(UserDto user);
    }
}