using Tokenize.API.Models.InputModels;

namespace Tokenize.API.Services.Interfaces;
    public interface IAccountService
    {
        void Register(RegisterInputModel inputModel);
        string Login(LoginInputModel inputModel);
        
    }