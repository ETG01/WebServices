using Tokenize.API.Models.DTOs;
using Tokenize.API.Models.Entities;

namespace Tokenize.API.Services.Interfaces;

    public interface IBookService
    {
        BookDto[] GetAllBooks();
        BookDetailsDto? GetBookById(int id);
        int CreateBook(Book book);
        void UpdateBookById(int id, Book updatedBook);
    }

