using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.EntityFrameworkCore;
using System.Text;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.OpenApi.Models;
using Tokenize.API.Repositories.Contexts;
using Tokenize.API.Repositories.Implementations;
using Tokenize.API.Repositories.Interfaces;
using Tokenize.API.Services.Implementations;
using Tokenize.API.Services.Interfaces;

// using Tokenize.API.Services; // Assuming you have this namespace for services

var builder = WebApplication.CreateBuilder(args);

// Register your services here
builder.Services.AddTransient<IAccountService, AccountService>();
builder.Services.AddTransient<IAccountRepository, AccountRepository>();
builder.Services.AddTransient<IJwtTokenService, JwtTokenService>();

builder.Services.AddTransient<IBookService, BookService>();
builder.Services.AddTransient<IBookRepository, BookRepository>();


// Register DbContext

builder.Services.AddDbContext<AuthenticationDbContext>(options =>
    options.UseSqlite(
        builder.Configuration.GetConnectionString("AuthenticationDbConnectionString"),
        b => b.MigrationsAssembly("Tokenize.API")
    )
);


// Register JWT Bearer authentication
var secret = builder.Configuration.GetValue<string>("JwtSettings:Secret");

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/login";
        options.ExpireTimeSpan = TimeSpan.FromMinutes(1);
    })
    .AddJwtBearer(options =>
    {
        var key = Encoding.ASCII.GetBytes(secret);
        options.SaveToken = true;
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration.GetValue<string>("JwtSettings:Issuer"), 
            ValidAudience = builder.Configuration.GetValue<string>("JwtSettings:Audience"), 
            IssuerSigningKey = new SymmetricSecurityKey(key),
            ClockSkew = TimeSpan.Zero
        };
    });




// Add services to the container.
builder.Services.AddControllers();

// Swagger and other services
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Tokenize", Version = "v1" });

    // Add security definition for JWT Bearer
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "JWT Authorization header using the Bearer scheme. Example: \"Bearer {token}\"",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            new string[] {}
        }
    });
});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthentication();

app.UseAuthorization();
app.Use(async (context, next) =>
{
    var token = context.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
    Console.WriteLine("Server's System DateTime: " + DateTime.Now);
    if (token != null)
    {
        var jwtToken = new JwtSecurityToken(token);
        Console.WriteLine($"Incoming Token: {token}");
        Console.WriteLine($"Token Expires: {jwtToken.ValidTo}");

        // Manual validation of token expiration
        if (jwtToken.ValidTo < DateTime.UtcNow)
        {
            context.Response.StatusCode = 401;
            await context.Response.WriteAsync("Token has expired");
            return;
        }
    }
    await next.Invoke();
});


app.MapControllers();

app.Run();
