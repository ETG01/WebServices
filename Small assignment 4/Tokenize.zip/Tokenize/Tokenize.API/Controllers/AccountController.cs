using Microsoft.AspNetCore.Mvc;
using Tokenize.API.Models.InputModels;
using Tokenize.API.Services.Interfaces;

namespace Tokenize.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountController : ControllerBase
    {
        private readonly IAccountService _accountService;

        public AccountController(IAccountService accountService)
        {
            _accountService = accountService;
        }

        [HttpPost("register")]
        public IActionResult Register([FromBody] RegisterInputModel inputModel)
        {
            _accountService.Register(inputModel);
            return Ok();
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginInputModel inputModel)
        {
            var token = _accountService.Login(inputModel);
            return Ok(token);
        }
        
    }
}