using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Tokenize.API.Models.Entities;
using Tokenize.API.Models.InputModels;
using Tokenize.API.Services.Interfaces;

namespace Tokenize.API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/[controller]")]
    public class BookController : ControllerBase
    {
        private readonly IBookService _bookService;

        public BookController(IBookService bookService)
        {
            _bookService = bookService;
        }
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetAllBooks")]
        public IActionResult GetAllBooks()
        {
            var books = _bookService.GetAllBooks();
            return Ok(books);
        }
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpGet("GetBookById/{id}")]
        public IActionResult GetBookById(int id)
        {
            var book = _bookService.GetBookById(id);
            if (book == null)
            {
                return NotFound();
            }
            return Ok(book);
        }
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPost("CreateBook")]
        public IActionResult CreateBook([FromBody] BookInputModel inputModel)
        {
            var bookId = _bookService.CreateBook(new Book
            {
                Name = inputModel.Name,
                Description = inputModel.Description,
                NumberOfPages = inputModel.NumberOfPages,
                CreatedDate = DateTime.Now,
            });
            return CreatedAtAction(nameof(GetBookById), new { id = bookId }, inputModel);
        }
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [HttpPut("UpdateBookById/{id}")]
        public IActionResult UpdateBookById(int id, [FromBody] BookInputModel inputModel)
        {
            var existingBook = _bookService.GetBookById(id);
            if (existingBook == null)
            {
                return NotFound();
            }

            _bookService.UpdateBookById(id, new Book
            {
                Name = inputModel.Name,
                Description = inputModel.Description,
                NumberOfPages = inputModel.NumberOfPages,
                ModifiedDate = DateTime.Now,
            });

            return NoContent();
        }
    }
}
