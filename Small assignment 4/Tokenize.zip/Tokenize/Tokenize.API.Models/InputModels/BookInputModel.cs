using System.ComponentModel.DataAnnotations;

namespace Tokenize.API.Models.InputModels
{
    public class BookInputModel
    {
        [Required(ErrorMessage = "Name is required.")]
        [StringLength(100, ErrorMessage = "Name cannot be longer than 100 characters.")]
        public string Name { get; set; }
        
        public string? Description { get; set; }

        [Required(ErrorMessage = "NumberOfPages is required.")]
        [Range(1, 10000, ErrorMessage = "NumberOfPages must be between 1 and 10000.")]
        public int NumberOfPages { get; set; }
    }
}