using System.ComponentModel.DataAnnotations;

namespace Tokenize.API.Models.InputModels
{
    public class RegisterInputModel
    {
        [Required]
        [MinLength(3)]
        public string FullName { get; set; } = "";

        [Required]
        [EmailAddress]
        public string EmailAddress { get; set; } = "";

        [Required]
        [MinLength(6)]
        public string Password { get; set; } = "";

        [Required]
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match.")]
        public string ConfirmPassword { get; set; }
    }
}