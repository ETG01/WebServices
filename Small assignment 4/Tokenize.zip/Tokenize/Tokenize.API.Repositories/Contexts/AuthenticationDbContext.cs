

using Tokenize.API.Models.Entities;
using Microsoft.EntityFrameworkCore;
namespace Tokenize.API.Repositories.Contexts;
public class AuthenticationDbContext : DbContext
{
    public AuthenticationDbContext(DbContextOptions<AuthenticationDbContext> options) : base(options) { }

    public DbSet<User> Users { get; set; } = null!;
    
    public DbSet<Book> Books { get; set; } = null!;
}