using Tokenize.API.Models.DTOs;
using Tokenize.API.Models.Entities;
using Tokenize.API.Models.InputModels;

namespace Tokenize.API.Repositories.Interfaces;
public interface IAccountRepository
{
    void Register(RegisterInputModel inputModel, string hashedPassword);
    UserDto? GetUser(string inputModelEmailAddress, string hashedPassword);
}
