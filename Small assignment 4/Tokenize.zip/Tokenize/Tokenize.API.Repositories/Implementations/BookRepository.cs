using System.Linq;
using Tokenize.API.Models.DTOs;
using Tokenize.API.Models.Entities;
using Microsoft.EntityFrameworkCore;
using Tokenize.API.Repositories.Contexts;
using Tokenize.API.Repositories.Interfaces;

namespace Tokenize.API.Repositories.Implementations;

public class BookRepository : IBookRepository
{
    private readonly AuthenticationDbContext _context;

    public BookRepository(AuthenticationDbContext context)
    {
        _context = context;
    }

    public BookDto[] GetAllBooks()
    {
        return _context.Books
            .Select(b => new BookDto
            {
                Id = b.Id,
                Name = b.Name,
                NumberOfPages = b.NumberOfPages
            })
            .ToArray();
    }

    public BookDetailsDto? GetBookById(int id)
    {
        return _context.Books
            .Where(b => b.Id == id)
            .Select(b => new BookDetailsDto
            {
                Id = b.Id,
                Name = b.Name,
                Description = b.Description,
                NumberOfPages = b.NumberOfPages
            })
            .FirstOrDefault();
    }

    public int CreateBook(Book book)
    {
        _context.Books.Add(book);
        _context.SaveChanges();
        return book.Id;
    }

    public void UpdateBookById(int id, Book updatedBook)
    {
        var book = _context.Books.Find(id);
        if (book != null)
        {
            book.Name = updatedBook.Name;
            book.Description = updatedBook.Description;
            book.NumberOfPages = updatedBook.NumberOfPages;
            book.ModifiedDate = DateTime.Now;
            _context.SaveChanges();
        }
    }
}