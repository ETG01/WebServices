using Tokenize.API.Models.DTOs;
using Tokenize.API.Models.Entities;
using Tokenize.API.Models.InputModels;
using Tokenize.API.Repositories.Contexts;
using Tokenize.API.Repositories.Interfaces;

namespace Tokenize.API.Repositories.Implementations;
    public class AccountRepository : IAccountRepository
    {
        private readonly AuthenticationDbContext _context;

        public AccountRepository(AuthenticationDbContext context)
        {
            _context = context;
        }

        public void Register(RegisterInputModel inputModel, string hashedPassword)
        {
            if (_context.Users.Any(u => u.EmailAddress == inputModel.EmailAddress))
            {
                return;
            }
            var user = new User
            {
                FullName = inputModel.FullName,
                EmailAddress = inputModel.EmailAddress,
                HashedPassword = hashedPassword,
                RegistrationDate = DateTime.Now
            };
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public UserDto? GetUser(string inputModelEmailAddress, string hashedPassword)
        {
            var user = _context.Users.FirstOrDefault(u => u.EmailAddress == inputModelEmailAddress && u.HashedPassword == hashedPassword);
            if (user == null) 
            {
                return null;
            }

            return new UserDto
            {
                Id = user.Id,
                FullName = user.FullName,
                EmailAddress = user.EmailAddress
            };
        }
    }