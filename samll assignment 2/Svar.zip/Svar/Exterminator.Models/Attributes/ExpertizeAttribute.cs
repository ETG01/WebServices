using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Exterminator.Models.Attributes
{
    public class ExpertizeAttribute : ValidationAttribute
    {
        private readonly string[] _validExpertizes = new[]
        {
            "Ghost catcher",
            "Ghoul strangler",
            "Monster encager",
            "Zombie exploder"
        };

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is string expertize && _validExpertizes.Contains(expertize))
            {
                return ValidationResult.Success;
            }

            return new ValidationResult("Invalid expertize & The Valid values are: “Ghost catcher”, “Ghoul strangler”, “Monster encager” or “Zombie exploder”");
        }
    }
}