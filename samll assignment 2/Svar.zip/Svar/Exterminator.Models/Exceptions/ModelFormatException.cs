using System;

namespace Exterminator.Models.Exceptions
{
    public class ModelFormatException : Exception
    {
        public ModelFormatException() : base() { }

        public ModelFormatException(string message) : base(message) { }

        public ModelFormatException(string message, Exception innerException) : base(message, innerException) { }
    }
}