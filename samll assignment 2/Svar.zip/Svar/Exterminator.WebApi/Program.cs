﻿using Exterminator.Repositories.Data;
using Exterminator.Repositories.Implementations;
using Exterminator.Repositories.Interfaces;
using Exterminator.Services.Implementations;
using Exterminator.Services.Interfaces;
using Exterminator.WebApi.ExceptionHandlerExtensions;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();

// Register your services here
builder.Services.AddScoped<ILogService, LogService>();
builder.Services.AddScoped<IGhostbusterService, GhostbusterService>();
builder.Services.AddScoped<ILogRepository, LogRepository>();
builder.Services.AddScoped<IGhostbusterRepository, GhostbusterRepository>();
builder.Services.AddScoped<IGhostbusterDbContext, GhostbusterDbContext>();




// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();


var app = builder.Build();

// register Global Exception Handler
app.UseGlobalExceptionHandler();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();


app.MapControllers();

app.Run();
