using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Exterminator.Services.Interfaces;
using Exterminator.Models;
using Exterminator.Models.Exceptions;
using System.Text.Json;

namespace Exterminator.WebApi.ExceptionHandlerExtensions
{
    public static class ExceptionHandlerExtensions
    {
        public static void UseGlobalExceptionHandler(this IApplicationBuilder app)
        {
            app.UseExceptionHandler(appBuilder =>
            {
                appBuilder.Run(async context =>
                {
                    var logService = context.RequestServices.GetRequiredService<ILogService>();
                    
                    var exceptionHandlerFeature = context.Features.Get<IExceptionHandlerFeature>();
                    var exception = exceptionHandlerFeature?.Error;
                    

                    int TheStatusCode = StatusCodes.Status500InternalServerError;

                    if (exception is ResourceNotFoundException)
                    {
                        TheStatusCode = StatusCodes.Status404NotFound;
                    }
                    else if (exception is ModelFormatException)
                    {
                        TheStatusCode = StatusCodes.Status412PreconditionFailed;
                    }
                    else if (exception is ArgumentOutOfRangeException)
                    {
                        TheStatusCode = StatusCodes.Status400BadRequest;
                    }

                    context.Response.StatusCode = TheStatusCode;
                    context.Response.ContentType = "application/json";
                    
                    var exceptionModel = new ExceptionModel
                    {
                        ExceptionMessage = exception?.Message,
                        StackTrace = exception?.StackTrace,
                        StatusCode = TheStatusCode,
                    };

                    logService.LogToDatabase(exceptionModel);

                    var response = JsonSerializer.Serialize(exceptionModel);
                    await context.Response.WriteAsync(response);
                });
            });
        }
    }
}
